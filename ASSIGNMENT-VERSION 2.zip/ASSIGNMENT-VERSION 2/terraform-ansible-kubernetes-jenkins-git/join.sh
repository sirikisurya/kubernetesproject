kubeadm join 10.0.0.10:6443 --token 4vq9qf.ndtels1gtghgi5gi --discovery-token-ca-cert-hash sha256:90eed17b327d40f660221659e7ddcb53e8177a4b91bbbd78392a40be7883eb36 
